<?php
session_start();

// 🔒 Security: Only ADMIN can add users
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: admin_login.php");
    exit;
}

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1️⃣ Capture & Validate Input
    $first_name     = trim($_POST['first_name'] ?? '');
    $last_name      = trim($_POST['last_name'] ?? '');
    $name           = $first_name . " " . $last_name;
    $email          = trim($_POST['email'] ?? '');
    $password_plain = $_POST['password'] ?? '';
    $confirm        = $_POST['confirm_password'] ?? '';
    
    // Teacher specific fields
    $role           = $_POST['role'] ?? 'TEACHER';
    $subject        = trim($_POST['subject'] ?? '');
    $institution    = trim($_POST['institution'] ?? '');
    $experience     = trim($_POST['experience'] ?? 0);

    if (empty($email) || empty($password_plain)) {
        die("Email and Password are required.");
    }

    if ($password_plain !== $confirm) {
        die("Passwords do not match.");
    }

    // 🛡️ Hash the password securely
    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    // 2️⃣ Start Transaction
    mysqli_begin_transaction($conn);

    try {
        // 3️⃣ INSERT INTO USERS TABLE (Using Prepared Statements)
        $stmt_user = mysqli_prepare($conn, "INSERT INTO users (role, name, email, password, status) VALUES (?, ?, ?, ?, 1)");
        mysqli_stmt_bind_param($stmt_user, "ssss", $role, $name, $email, $password_hashed);
        
        if (!mysqli_stmt_execute($stmt_user)) {
            throw new Exception("User insertion failed: " . mysqli_stmt_error($stmt_user));
        }

        $user_id = mysqli_insert_id($conn);

        // 4️⃣ INSERT INTO TEACHERS TABLE
        if ($role === 'TEACHER') {
            $stmt_teacher = mysqli_prepare($conn, "INSERT INTO teachers (user_id, subject, institution, experience) VALUES (?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt_teacher, "issi", $user_id, $subject, $institution, $experience);
            
            if (!mysqli_stmt_execute($stmt_teacher)) {
                throw new Exception("Teacher record creation failed: " . mysqli_stmt_error($stmt_teacher));
            }
        }

        // 5️⃣ Commit changes
        mysqli_commit($conn);

        // ✅ SUCCESS
        header("Location: register_teacher_form.php?success=1");
        exit;

    } catch (Exception $e) {
        // ❌ ERROR: Rollback
        mysqli_rollback($conn);
        die("Transaction failed: " . $e->getMessage());
    }
}
?>
