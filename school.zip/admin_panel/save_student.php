<?php
session_start();

// 🔒 Security: Only ADMIN can enroll students
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: admin_login.php");
    exit;
}

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1️⃣ Capture & Validate Input
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $class    = trim($_POST['class'] ?? '');
    $roll_no  = trim($_POST['roll_no'] ?? '');
    $password_plain = $_POST['password'] ?? '';

    if (empty($email) || empty($password_plain) || empty($roll_no)) {
        die("Missing required student fields.");
    }

    // 🛡️ Hash the password securely
    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    // 2️⃣ Start Transaction
    mysqli_begin_transaction($conn);

    try {
        // 3️⃣ INSERT INTO USERS TABLE
        $stmt_u = mysqli_prepare($conn, "INSERT INTO users (role, name, email, password, status) VALUES ('STUDENT', ?, ?, ?, 1)");
        mysqli_stmt_bind_param($stmt_u, "sss", $name, $email, $password_hashed);
        
        if (!mysqli_stmt_execute($stmt_u)) {
            throw new Exception("User account creation failed: " . mysqli_stmt_error($stmt_u));
        }

        $user_id = mysqli_insert_id($conn);

        // 4️⃣ INSERT INTO STUDENTS TABLE
        $stmt_s = mysqli_prepare($conn, "INSERT INTO students (user_id, class, roll_no) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt_s, "iss", $user_id, $class, $roll_no);
        
        if (!mysqli_stmt_execute($stmt_s)) {
            throw new Exception("Student record profile failed: " . mysqli_stmt_error($stmt_s));
        }

        // 5️⃣ Commit changes
        mysqli_commit($conn);

        // ✅ SUCCESS
        header("Location: register_student.php?success=1");
        exit;

    } catch (Exception $e) {
        // ❌ ERROR: Rollback
        mysqli_rollback($conn);
        die("Enrollment failed: " . $e->getMessage());
    }
}
?>
