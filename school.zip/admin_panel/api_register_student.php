<?php
header('Content-Type: application/json');
session_start();

// Auth check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["success" => false, "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data (can be from $_POST if using FormData or from php://input if using JSON)
    $name     = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    $email    = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $password_plain = trim($_POST['password'] ?? '');
    $class    = mysqli_real_escape_string($conn, $_POST['class'] ?? '');
    $batch    = mysqli_real_escape_string($conn, $_POST['batch'] ?? '');
    $roll_no  = mysqli_real_escape_string($conn, $_POST['roll_no'] ?? '');

    // Validation
    if (empty($name) || empty($email) || empty($password_plain) || empty($class) || empty($batch) || empty($roll_no)) {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
        exit;
    }

    $password_hash = password_hash($password_plain, PASSWORD_DEFAULT);

    // 1. Insert into users table
    $userQuery = "INSERT INTO users (name, email, password, role, status)
                  VALUES ('$name', '$email', '$password_hash', 'STUDENT', 1)";

    if (mysqli_query($conn, $userQuery)) {
        $user_id = mysqli_insert_id($conn);

        // 2. Insert into students table
        $studentQuery = "INSERT INTO students (user_id, class, batch, roll_no)
                         VALUES ($user_id, '$class', '$batch', '$roll_no')";

        if (mysqli_query($conn, $studentQuery)) {
            echo json_encode(["success" => true, "message" => "Student registered successfully!"]);
        } else {
            // Rollback user if student record fails (basic)
            mysqli_query($conn, "DELETE FROM users WHERE id = $user_id");
            echo json_encode(["success" => false, "message" => "Failed to create student profile."]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "User already exists or database error."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
}
?>
