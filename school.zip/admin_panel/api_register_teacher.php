<?php
header('Content-Type: application/json');
session_start();

// Auth check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["success" => false, "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $first_name     = mysqli_real_escape_string($conn, trim($_POST['first_name'] ?? ''));
    $last_name      = mysqli_real_escape_string($conn, trim($_POST['last_name'] ?? ''));
    $name           = $first_name . " " . $last_name;
    $email          = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $password_plain = $_POST['password'] ?? '';
    $confirm        = $_POST['confirm_password'] ?? '';
    
    $role           = 'TEACHER';
    $subject        = mysqli_real_escape_string($conn, trim($_POST['subject'] ?? ''));
    $institution    = mysqli_real_escape_string($conn, trim($_POST['institution'] ?? ''));
    $experience     = (int)($_POST['experience'] ?? 0);

    if (empty($email) || empty($password_plain)) {
        echo json_encode(["success" => false, "message" => "Email and Password are required."]);
        exit;
    }

    if ($password_plain !== $confirm) {
        echo json_encode(["success" => false, "message" => "Passwords do not match."]);
        exit;
    }

    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    mysqli_begin_transaction($conn);

    try {
        $stmt_user = mysqli_prepare($conn, "INSERT INTO users (role, name, email, password, status) VALUES (?, ?, ?, ?, 1)");
        mysqli_stmt_bind_param($stmt_user, "ssss", $role, $name, $email, $password_hashed);
        
        if (!mysqli_stmt_execute($stmt_user)) {
            throw new Exception("User insertion failed.");
        }

        $user_id = mysqli_insert_id($conn);

        $stmt_teacher = mysqli_prepare($conn, "INSERT INTO teachers (user_id, subject, institution, experience) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt_teacher, "issi", $user_id, $subject, $institution, $experience);
        
        if (!mysqli_stmt_execute($stmt_teacher)) {
            throw new Exception("Teacher record creation failed.");
        }

        mysqli_commit($conn);
        echo json_encode(["success" => true, "message" => "Teacher registered successfully!"]);

    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(["success" => false, "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
}
?>
