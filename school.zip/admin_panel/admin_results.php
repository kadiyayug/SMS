<?php
session_start();
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER'])) {
    header("Location: index.php");
    exit;
}
require_once 'db.php';
// Pre-load students for selection
$students_q = mysqli_query($conn, "SELECT s.id, u.name, s.roll_no FROM students s JOIN users u ON s.user_id = u.id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Results Dashboard | Sharda Vidhya Mandir</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #8b5cf6;
            --accent: #10b981;
            --danger: #f43f5e;
            --bg-color: #f8fafc;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Space Grotesk', sans-serif; }

        body {
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(at 100% 0%, rgba(99, 102, 241, 0.1) 0px, transparent 50%),
                radial-gradient(at 0% 100%, rgba(139, 92, 246, 0.1) 0px, transparent 50%);
            min-height: 100vh;
            color: #0f172a;
        }

        /* Nav */
        nav {
            padding: 25px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(15px);
            background: rgba(255, 255, 255, 0.7);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            position: sticky; top: 0; z-index: 100;
        }

        .logo { font-size: 24px; font-weight: 800; color: var(--primary-dark); display: flex; align-items: center; gap: 12px; }
        .logo i { background: var(--primary); color: white; width: 42px; height: 42px; border-radius: 12px; display: flex; align-items: center; justify-content: center; transform: rotate(-5deg); box-shadow: 0 10px 20px rgba(99, 102, 241, 0.2); }

        .container { max-width: 1300px; margin: 50px auto; padding: 0 30px; display: grid; grid-template-columns: 1fr 2fr; gap: 40px; }

        /* Generic Glass Card */
        .card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 35px;
            padding: 40px;
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.05);
            animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }

        h2 { font-size: 26px; font-weight: 700; color: #1e293b; margin-bottom: 30px; display: flex; align-items: center; gap: 15px; }
        h2 i { color: var(--primary); }

        /* Form Controls */
        .form-group { margin-bottom: 25px; }
        label { display: block; font-size: 13px; font-weight: 700; color: #64748b; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px; }
        
        .input-wrapper { position: relative; }
        .input-wrapper i { position: absolute; left: 18px; top: 50%; transform: translateY(-50%); color: #94a3b8; font-size: 14px; }
        
        input, select {
            width: 100%; padding: 16px 16px 16px 48px;
            background: white; border: 2.5px solid #f1f5f9; border-radius: 20px;
            font-size: 15px; color: #1e293b; outline: none; transition: 0.3s;
        }
        input:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 5px rgba(99, 102, 241, 0.1); }

        .btn-submit {
            width: 100%; padding: 20px; border-radius: 20px; font-weight: 800; border: none; cursor: pointer; transition: 0.3s;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white;
            display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 20px;
            box-shadow: 0 15px 30px rgba(99, 102, 241, 0.3);
        }
        .btn-submit:hover { transform: translateY(-3px) scale(1.02); box-shadow: 0 20px 40px rgba(99, 102, 241, 0.4); }

        /* Table Area */
        .table-wrap { overflow-x: auto; }
        #results-table { width: 100%; border-collapse: separate; border-spacing: 0 12px; }
        #results-table th { padding: 0 25px 15px; text-align: left; font-size: 12px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 1.5px; }
        
        .result-row { background: white; transition: 0.3s; border-radius: 20px; }
        .result-row:hover { transform: scale(1.01); box-shadow: 0 10px 30px rgba(0,0,0,0.03); }
        .result-row td { padding: 20px 25px; border-top: 1px solid #f1f5f9; border-bottom: 1px solid #f1f5f9; }
        .result-row td:first-child { border-left: 1px solid #f1f5f9; border-radius: 20px 0 0 20px; }
        .result-row td:last-child { border-right: 1px solid #f1f5f9; border-radius: 0 20px 20px 0; }

        .badge { padding: 8px 16px; border-radius: 12px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; }
        .badge.pass { background: #dcfce7; color: #10b981; }
        .badge.fail { background: #fee2e2; color: #f43f5e; }

        .score-circle { width: 45px; height: 45px; border-radius: 50%; background: #f1f5f9; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; margin-bottom: 5px; }

        #alert { position: fixed; top: 40px; right: 40px; padding: 20px 35px; border-radius: 25px; background: white; border: 1px solid #e2e8f0; box-shadow: 0 25px 50px rgba(0,0,0,0.1); display: none; z-index: 2000; animation: bounceIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        @keyframes bounceIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

        @media (max-width: 1024px) { .container { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

    <nav>
        <div class="logo">
            <i class="fas fa-graduation-cap"></i>
            Results Nexus
        </div>
        <div style="display: flex; gap: 20px; align-items: center;">
            <a href="admin_dashboard.php" style="text-decoration: none; color: #64748b; font-weight: 700; font-size: 14px;"><i class="fas fa-home"></i> Back Home</a>
            <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['name']) ?>&background=6366f1&color=fff" style="width: 40px; height: 40px; border-radius: 14px;">
        </div>
    </nav>

    <div class="container">
        <!-- Add Result Sidebar -->
        <div class="card">
            <h2><i class="fas fa-edit"></i> Publish Result</h2>
            <form id="resultForm">
                <div class="form-group">
                    <label>Assigned Student</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user-graduate"></i>
                        <select name="student_id" required>
                            <option value="">Select Student...</option>
                            <?php while($s = mysqli_fetch_assoc($students_q)): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (Roll: <?= $s['roll_no'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Examination Context</label>
                    <div class="input-wrapper">
                        <i class="fas fa-file-signature"></i>
                        <input type="text" name="exam_name" placeholder="Annual Final / Mid-Term" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Curriculum Subject</label>
                    <div class="input-wrapper">
                        <i class="fas fa-book"></i>
                        <input type="text" name="subject" placeholder="Mathematics / Physics" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Score</label>
                        <div class="input-wrapper">
                            <i class="fas fa-star" style="color: var(--primary);"></i>
                            <input type="number" name="marks_obtained" placeholder="0" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Max Scale</label>
                        <div class="input-wrapper">
                            <i class="fas fa-flag"></i>
                            <input type="number" name="total_marks" value="100" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Session Date</label>
                    <div class="input-wrapper">
                        <i class="fas fa-calendar-day"></i>
                        <input type="date" name="exam_date" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>

                <button type="submit" class="btn-submit" id="subBtn">
                    <i class="fas fa-paper-plane"></i> Sync to Database
                </button>
            </form>
        </div>

        <!-- History Content -->
        <div>
            <div style="margin-bottom: 30px; display: flex; justify-content: space-between; align-items: flex-end;">
                <div>
                    <h2 style="margin-bottom: 5px;">Academic Ledger</h2>
                    <p style="color: #64748b; font-weight: 500;">Recently published examination records.</p>
                </div>
                <div style="background: white; padding: 10px 20px; border-radius: 15px; border: 1px solid #e2e8f0; font-size: 13px; font-weight: 800; color: var(--primary-dark);">
                    LIVE UPDATES ACTIVE
                </div>
            </div>

            <div class="table-wrap">
                <table id="results-table">
                    <thead>
                        <tr>
                            <th>Student & Context</th>
                            <th>Subject</th>
                            <th style="text-align: center;">Performance</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <!-- AJAX DATA -->
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 100px; color: #94a3b8;">
                                <i class="fas fa-circle-notch fa-spin fa-2x"></i>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="alert">Sync Successful!</div>

    <script>
        const body = document.getElementById('tableBody');
        const form = document.getElementById('resultForm');
        const alertBox = document.getElementById('alert');
        const btn = document.getElementById('subBtn');

        async function fetchResults() {
            try {
                const res = await fetch('api_results.php?action=list');
                const result = await res.json();
                
                if(result.status === 'success') {
                    body.innerHTML = result.data.map(r => `
                        <tr class="result-row">
                            <td>
                                <div style="font-weight: 800; font-size: 16px;">${r.student_name}</div>
                                <div style="font-size: 12px; color: #64748b; margin-top: 5px;"><i class="fas fa-layer-group"></i> ${r.exam_name}</div>
                            </td>
                            <td>
                                <div style="font-weight: 700; color: var(--primary-dark);">${r.subject}</div>
                                <div style="font-size: 11px; color: #94a3b8; text-transform: uppercase;">${r.exam_date}</div>
                            </td>
                            <td align="center">
                                <div class="score-circle" style="color: ${r.percentage >= 40 ? '#10b981' : '#f43f5e'}">${r.marks_obtained}</div>
                                <div style="font-size: 10px; font-weight: 800; color: #cbd5e1;">OF ${r.total_marks}</div>
                            </td>
                            <td>
                                <span class="badge ${r.status === 'PASSED' ? 'pass' : 'fail'}">${r.status}</span>
                            </td>
                            <td>
                                <button class="delete-btn" onclick="deleteResult(${r.id})" style="border: none; background: none; color: #ff0000; cursor: pointer; opacity: 0.3;"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                    `).join('');

                    if(result.data.length === 0) {
                        body.innerHTML = '<tr><td colspan="5" align="center" style="padding: 50px;">No academic records found.</td></tr>';
                    }
                }
            } catch(e) {
                body.innerHTML = '<tr><td colspan="5" align="center" style="color: red; padding: 50px;">Critical connectivity failure.</td></tr>';
            }
        }

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-sync fa-spin"></i> SYNCING...';

            const formData = new FormData(form);
            formData.append('action', 'save');

            try {
                const res = await fetch('api_results.php', { method: 'POST', body: formData });
                const result = await res.json();
                
                if(result.status === 'success') {
                    showAlert(result.message, '#10b981');
                    form.reset();
                    fetchResults();
                } else {
                    showAlert(result.message, '#f43f5e');
                }
            } catch(e) {
                showAlert('System sync error.', '#f43f5e');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-paper-plane"></i> Sync to Database';
            }
        });

        async function deleteResult(id) {
            if(!confirm('Purge result record ID: ' + id + '?')) return;
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('id', id);
            await fetch('api_results.php', { method: 'POST', body: formData });
            fetchResults();
        }

        function showAlert(msg, bg) {
            alertBox.innerText = msg;
            alertBox.style.borderColor = bg;
            alertBox.style.color = bg;
            alertBox.style.display = 'block';
            setTimeout(() => alertBox.style.display = 'none', 4000);
        }

        fetchResults();
    </script>
</body>
</html>
