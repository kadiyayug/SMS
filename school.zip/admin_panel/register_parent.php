<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: index.php");
    exit;
}

include 'db.php';

// Fetch current students for the dropdown
$studentsResult = mysqli_query($conn,"
    SELECT s.id, u.name, s.class, s.batch
    FROM students s
    JOIN users u ON s.user_id = u.id
    ORDER BY u.name ASC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Registration | Sharda Vidhya Mandir</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #f59e0b;
            --primary-dark: #d97706;
            --secondary: #6366f1;
            --glass: rgba(255, 255, 255, 0.7);
            --glass-border: rgba(255, 255, 255, 0.3);
            --bg-gradient: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Outfit', sans-serif; }

        body {
            background: var(--bg-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px 20px;
            overflow-x: hidden;
        }

        /* Animated Elements */
        .blob {
            position: fixed;
            width: 500px; height: 500px;
            background: rgba(245, 158, 11, 0.1);
            filter: blur(100px);
            border-radius: 50%;
            z-index: -1;
            animation: move-obj 30s infinite alternate;
        }
        @keyframes move-obj {
            from { transform: translate(-10%, -10%); }
            to { transform: translate(40%, 20%); }
        }

        .container {
            width: 100%;
            max-width: 950px;
            display: flex;
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 40px;
            box-shadow: 0 40px 100px -20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: slideUp 0.7s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Sidebar Sidebar */
        .sidebar {
            width: 40%;
            background: linear-gradient(180deg, #f59e0b 0%, #b45309 100%);
            padding: 60px 45px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar h1 { font-size: 40px; font-weight: 800; line-height: 1.1; margin-bottom: 25px; }
        .sidebar p { font-size: 17px; opacity: 0.9; line-height: 1.6; font-weight: 300; }

        .feature-item { display: flex; align-items: center; gap: 15px; margin-top: 35px; }
        .feature-item i { width: 45px; height: 45px; background: rgba(255,255,255,0.2); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 18px; }

        /* Form Area */
        .form-area { flex: 1; padding: 60px; }
        h2 { font-size: 26px; font-weight: 700; color: #1e293b; margin-bottom: 35px; display: flex; align-items: center; gap: 15px; }
        h2 i { color: var(--primary); }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .full-width { grid-column: span 2; }

        .form-group { margin-bottom: 20px; }
        label { display: block; font-size: 13px; font-weight: 700; color: #64748b; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .input-wrapper { position: relative; }
        .input-wrapper i { position: absolute; left: 18px; top: 50%; transform: translateY(-50%); color: #94a3b8; }

        input, select {
            width: 100%; padding: 15px 15px 15px 48px;
            background: rgba(255,255,255,0.8); border: 2px solid #e2e8f0; border-radius: 18px;
            font-size: 15px; color: #1e293b; outline: none; transition: 0.3s;
        }
        input:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 5px rgba(245, 158, 11, 0.1); }

        .btn-submit {
            width: 100%; padding: 18px; border-radius: 18px; font-weight: 800; cursor: pointer; transition: 0.3s; border: none;
            background: linear-gradient(135deg, #f59e0b 0%, #b45309 100%); color: white;
            display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 20px;
            box-shadow: 0 10px 25px rgba(245, 158, 11, 0.3);
        }

        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 15px 35px rgba(245, 158, 11, 0.4); }
        .btn-submit:disabled { opacity: 0.7; cursor: not-allowed; }

        #alert { margin-top: 25px; padding: 18px; border-radius: 18px; display: none; font-weight: 600; text-align: center; animation: zoomIn 0.3s ease; }
        @keyframes zoomIn { from { scale: 0.9; opacity: 0; } to { scale: 1; opacity: 1; } }

        .success { background: #dcfce7; color: #166534; border: 2px solid #bbf7d0; }
        .error { background: #fee2e2; color: #991b1b; border: 2px solid #fecaca; }

        @media (max-width: 900px) {
            .container { flex-direction: column; }
            .sidebar { width: 100%; padding: 40px; }
            .form-area { padding: 40px; }
            .form-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
        }
    </style>
</head>
<body>
    <div class="blob"></div>
    
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div>
                <h1>Parental Gateway</h1>
                <p>Register parents and link them to their children for seamless communication and progress tracking.</p>
                
                <div class="feature-item">
                    <i class="fas fa-link"></i>
                    <span>Connect parent to student records</span>
                </div>
                <div class="feature-item">
                    <i class="fas fa-bell"></i>
                    <span>Enable notification access</span>
                </div>
                <div class="feature-item">
                    <i class="fas fa-lock"></i>
                    <span>Secure portal authentication</span>
                </div>
            </div>
            
            <a href="admin_dashboard.php" style="color: white; text-decoration: none; font-weight: 600; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-arrow-left"></i> Exit to Dashboard
            </a>
        </div>

        <!-- Form Area -->
        <div class="form-area">
            <h2><i class="fas fa-user-friends"></i> Register Parent</h2>
            
            <form id="parentForm" class="form-grid">
                <!-- Name -->
                <div class="form-group">
                    <label>Guardian Name</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user"></i>
                        <input type="text" name="name" placeholder="Full Name" required>
                    </div>
                </div>

                <!-- Phone -->
                <div class="form-group">
                    <label>Primary Phone</label>
                    <div class="input-wrapper">
                        <i class="fas fa-phone"></i>
                        <input type="text" name="phone" placeholder="+91 12345 67890" required>
                    </div>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label>Email Address</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" placeholder="example@gmail.com" required>
                    </div>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label>Access Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-key"></i>
                        <input type="password" name="password" placeholder="••••••••" required>
                    </div>
                </div>

                <!-- Student Selection -->
                <div class="form-group full-width">
                    <label>Link Student Profile</label>
                    <div class="input-wrapper">
                        <i class="fas fa-id-card"></i>
                        <select name="student_id" required>
                            <option value="">Select Student...</option>
                            <?php while($s = mysqli_fetch_assoc($studentsResult)): ?>
                                <option value="<?= $s['id'] ?>">
                                    <?= htmlspecialchars($s['name']) ?> (Class <?= $s['class'] ?> - <?= $s['batch'] ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <div class="full-width">
                    <button type="submit" class="btn-submit" id="subBtn">
                        <i class="fas fa-user-plus"></i> Complete Onboarding
                    </button>
                    <div id="alert"></div>
                </div>
            </form>
        </div>
    </div>

    <script>
        const form = document.getElementById('parentForm');
        const alertBox = document.getElementById('alert');
        const btn = document.getElementById('subBtn');

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-sync fa-spin"></i> Processing...';
            alertBox.style.display = 'none';

            const formData = new FormData(form);

            try {
                const response = await fetch('api_register_parent.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();

                alertBox.style.display = 'block';
                if (data.success) {
                    alertBox.className = 'success';
                    alertBox.innerHTML = `<i class="fas fa-check-circle"></i> ${data.message}`;
                    form.reset();
                } else {
                    alertBox.className = 'error';
                    alertBox.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${data.message}`;
                }
            } catch (err) {
                alertBox.style.display = 'block';
                alertBox.className = 'error';
                alertBox.innerHTML = '<i class="fas fa-wifi"></i> Connection failed';
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-user-plus"></i> Complete Onboarding';
            }
        });
    </script>
</body>
</html>
