<?php
header('Content-Type: application/json');
session_start();

// Auth check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["success" => false, "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name           = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    $email          = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $password_plain = $_POST['password'] ?? '';
    $phone          = mysqli_real_escape_string($conn, trim($_POST['phone'] ?? ''));
    $student_id     = (int)($_POST['student_id'] ?? 0);

    if (empty($name) || empty($email) || empty($password_plain) || empty($student_id)) {
        echo json_encode(["success" => false, "message" => "All fields (Name, Email, Password, Student) are required."]);
        exit;
    }

    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    mysqli_begin_transaction($conn);

    try {
        $stmt_user = mysqli_prepare($conn, "INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, 'PARENT', 1)");
        mysqli_stmt_bind_param($stmt_user, "sss", $name, $email, $password_hashed);
        
        if (!mysqli_stmt_execute($stmt_user)) {
            throw new Exception("User registration failed.");
        }

        $user_id = mysqli_insert_id($conn);

        $stmt_parent = mysqli_prepare($conn, "INSERT INTO parents (user_id, student_id, phone) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt_parent, "iis", $user_id, $student_id, $phone);
        
        if (!mysqli_stmt_execute($stmt_parent)) {
            throw new Exception("Parent record creation failed.");
        }

        mysqli_commit($conn);
        echo json_encode(["success" => true, "message" => "Parent registered successfully!"]);

    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(["success" => false, "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
}
?>
