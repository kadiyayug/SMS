<?php
session_start();

// Database connection
include 'db.php';

// If form submitted using fetch (AJAX)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query from users table (ADMIN only)
    $query = "SELECT * FROM users 
              WHERE email='$username' 
              AND password='$password' 
              AND role='ADMIN'";

    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        $_SESSION['admin'] = $username;

        echo json_encode([
            "status" => "success",
            "redirect" => "admin_dashboard.php"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Invalid Username or Password!"
        ]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | School Management</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #4facfe, #00f2fe);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            width: 800px;
            height: 400px;
            background: #fff;
            display: flex;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .login-left {
            width: 40%;
            background: #0d6efd;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .login-right {
            width: 60%;
            padding: 50px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-btn {
            width: 100%;
            padding: 12px;
            background: #0d6efd;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        #message-box {
            display: none;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
        }
        .error-msg {
            background: #f8d7da;
            color: #721c24;
        }
        .success-msg {
            background: #d4edda;
            color: #155724;
        }
    </style>
</head>

<body>

<div class="login-container">
    <div class="login-left">
        <img src="images.jpg" style="width:100px;">
        <h2>Sharda Vidhya Mandir Sancul</h2>
    </div>

    <div class="login-right">
        <h2> Login</h2>

        <div id="message-box"></div>

        <form id="loginForm">
            <div class="form-group">
                <input type="text" name="username" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>
</div>

<script>
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const msgBox = document.getElementById('message-box');
    const formData = new FormData(this);

    msgBox.style.display = 'block';
    msgBox.className = 'success-msg';
    msgBox.innerHTML = 'Checking credentials...';

    fetch('admin_login.php', {   // SAME FILE
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            msgBox.className = 'success-msg';
            msgBox.innerHTML = 'Login successful!';
            setTimeout(() => window.location.href = data.redirect, 1000);
        } else {
            msgBox.className = 'error-msg';
            msgBox.innerHTML = data.message;
        }
    })
    .catch(() => {
        msgBox.className = 'error-msg';
        msgBox.innerHTML = 'Server error';
    });
});
</script>

</body>
</html>
