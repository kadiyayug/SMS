<?php
header('Content-Type: application/json');
session_start();

// Admin protection
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'list') {
    // Fetch fee records
    $query = "
        SELECT 
            f.id,
            u.name AS student_name,
            f.amount,
            f.status,
            f.razorpay_payment_id,
            f.payment_date
        FROM fees f
        JOIN students s ON f.student_id = s.id
        JOIN users u ON s.user_id = u.id
        ORDER BY f.payment_date DESC
    ";
    
    $result = mysqli_query($conn, $query);
    $fees = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $row['formatted_date'] = $row['payment_date'] ? date("d M Y, h:i A", strtotime($row['payment_date'])) : '-';
        $row['formatted_amount'] = '₹' . number_format($row['amount']);
        $fees[] = $row;
    }
    
    echo json_encode(["status" => "success", "data" => $fees]);
} 
else if ($action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $del = mysqli_query($conn, "DELETE FROM fees WHERE id = $id");
        if ($del) {
            echo json_encode(["status" => "success", "message" => "Record deleted."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Delete failed."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid ID."]);
    }
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
