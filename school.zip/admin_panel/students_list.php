<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER'])) {
    header("Location: index.php");
    exit;
}

$students_q = mysqli_query($conn, "
    SELECT u.name, s.class, s.roll_no, u.email
    FROM students s 
    JOIN users u ON s.user_id = u.id
    ORDER BY s.class, s.roll_no
");

if (!$students_q) {
    die("Error fetching student list: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student List</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">

<nav class="bg-white shadow px-8 py-4 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-xl font-bold text-gray-800">📋 Student Directory</h1>
    <?php 
        $dash = ($_SESSION['role']==='ADMIN') ? 'admin_dashboard.php' : 'teacher_dashboard.php';
    ?>
    <a href="<?= $dash ?>" class="px-4 py-2 bg-indigo-600 text-white rounded">Dashboard</a>
</nav>

<main class="max-w-6xl mx-auto py-10 px-6">
    <div class="bg-white rounded-3xl shadow p-8">
        <h2 class="text-xl font-bold mb-6">Assigned Students</h2>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="p-4">Name</th>
                        <th class="p-4">Class</th>
                        <th class="p-4">Roll No</th>
                        <th class="p-4">Email</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($s = mysqli_fetch_assoc($students_q)): ?>
                    <tr class="border-b">
                        <td class="p-4 font-semibold"><?= htmlspecialchars($s['name']) ?></td>
                        <td class="p-4"><?= htmlspecialchars($s['class']) ?></td>
                        <td class="p-4"><?= htmlspecialchars($s['roll_no']) ?></td>
                        <td class="p-4 text-gray-600"><?= htmlspecialchars($s['email']) ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

</body>
</html>
