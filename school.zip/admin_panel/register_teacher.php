<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: admin_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Onboarding | Sharda Vidhya Mandir</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #ec4899;
            --accent: #10b981;
            --glass: rgba(255, 255, 255, 0.7);
            --glass-border: rgba(255, 255, 255, 0.2);
            --bg-gradient: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Outfit', sans-serif; }

        body {
            background: var(--bg-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Background Blobs */
        .blob {
            position: fixed;
            width: 500px; height: 500px;
            background: rgba(99, 102, 241, 0.1);
            filter: blur(100px);
            border-radius: 50%;
            z-index: -1;
            animation: drift 25s infinite alternate;
        }
        @keyframes drift {
            from { transform: translate(-20%, -20%); }
            to { transform: translate(30%, 30%); }
        }

        .container {
            width: 100%;
            max-width: 900px;
            display: flex;
            background: var(--glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--glass-border);
            border-radius: 40px;
            box-shadow: 0 40px 100px -20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: scaleIn 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes scaleIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }

        /* Sidebar Info */
        .sidebar {
            width: 35%;
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            padding: 50px 40px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar h1 { font-size: 36px; font-weight: 800; line-height: 1.1; margin-bottom: 20px; }
        .sidebar p { font-size: 16px; opacity: 0.8; line-height: 1.6; }

        .progress-list { margin-top: 40px; }
        .progress-item {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
            opacity: 0.4;
            transition: 0.4s;
        }
        .progress-item.active { opacity: 1; transform: translateX(5px); }
        .progress-item i { width: 30px; height: 30px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; }
        .progress-item.active i { background: white; color: var(--primary); }

        /* Form Area */
        .form-area { flex: 1; padding: 60px; position: relative; }

        .step { display: none; width: 100%; }
        .step.active { display: block; animation: slideIn 0.5s ease; }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        h2 { font-size: 28px; font-weight: 700; color: #1e293b; margin-bottom: 30px; }

        .form-group { margin-bottom: 25px; }
        label { display: block; font-size: 14px; font-weight: 600; color: #64748b; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .input-wrapper { position: relative; }
        .input-wrapper i { position: absolute; left: 20px; top: 50%; transform: translateY(-50%); color: #94a3b8; }

        input, select {
            width: 100%; padding: 15px 20px 15px 50px;
            background: white; border: 2px solid #e2e8f0; border-radius: 18px;
            font-size: 16px; color: #1e293b; outline: none; transition: 0.3s;
        }
        input:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 5px rgba(99, 102, 241, 0.1); }

        .btn-row { display: flex; gap: 15px; margin-top: 40px; }
        .btn { padding: 16px 30px; border-radius: 18px; font-weight: 700; cursor: pointer; transition: 0.3s; border: none; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .btn-outline { background: white; border: 2px solid #e2e8f0; color: #64748b; flex: 1; }
        .btn-outline:hover { background: #f8fafc; border-color: #cbd5e1; }
        .btn-primary { background: var(--primary); color: white; flex: 2; box-shadow: 0 10px 20px rgba(99, 102, 241, 0.2); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 15px 30px rgba(99, 102, 241, 0.3); }

        #toast { position: fixed; bottom: 40px; right: 40px; padding: 20px 30px; border-radius: 20px; color: white; font-weight: 600; display: none; animation: pop 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); z-index: 1000; }
        @keyframes pop { from { transform: translateY(100px) scale(0.8); opacity: 0; } to { transform: translateY(0) scale(1); opacity: 1; } }

        @media (max-width: 768px) {
            .container { flex-direction: column; }
            .sidebar { width: 100%; padding: 40px; }
            .form-area { padding: 40px; }
        }
    </style>
</head>
<body>
    <div class="blob"></div>
    
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div>
                <h1>Teacher<br>Onboarding</h1>
                <p>Register new academic staff with specialized credentials and professional history.</p>
                
                <div class="progress-list">
                    <div class="progress-item active" id="p-1">
                        <i class="fas fa-user-plus"></i>
                        <span>Personal info</span>
                    </div>
                    <div class="progress-item" id="p-2">
                        <i class="fas fa-graduation-cap"></i>
                        <span>Professional info</span>
                    </div>
                    <div class="progress-item" id="p-3">
                        <i class="fas fa-shield-alt"></i>
                        <span>Security</span>
                    </div>
                </div>
            </div>
            
            <a href="admin_dashboard.php" style="color: white; text-decoration: none; font-weight: 600; font-size: 14px;">
                <i class="fas fa-arrow-left"></i> Return to Dashboard
            </a>
        </div>

        <!-- Form Area -->
        <div class="form-area">
            <form id="regForm">
                <!-- STEP 1: Personal -->
                <div class="step active" id="step-1">
                    <h2>Personal Details</h2>
                    <div class="form-group">
                        <label>First Name</label>
                        <div class="input-wrapper">
                            <i class="fas fa-user"></i>
                            <input type="text" name="first_name" placeholder="John" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <div class="input-wrapper">
                            <i class="fas fa-id-badge"></i>
                            <input type="text" name="last_name" placeholder="Doe" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <div class="input-wrapper">
                            <i class="fas fa-envelope"></i>
                            <input type="email" name="email" placeholder="john.doe@school.com" required>
                        </div>
                    </div>
                    <div class="btn-row">
                        <button type="button" class="btn btn-primary" onclick="nextStep(2)">
                            Continue <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>

                <!-- STEP 2: Professional -->
                <div class="step" id="step-2">
                    <h2>Professional Info</h2>
                    <div class="form-group">
                        <label>Specialization Subject</label>
                        <div class="input-wrapper">
                            <i class="fas fa-book-open"></i>
                            <select name="subject" required>
                                <option value="Mathematics">Mathematics</option>
                                <option value="Science">Science</option>
                                <option value="Computer">Computer Science</option>
                                <option value="English">English</option>
                                <option value="History">History</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Last Institution</label>
                        <div class="input-wrapper">
                            <i class="fas fa-school"></i>
                            <input type="text" name="institution" placeholder="Previous School Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Experience (Years)</label>
                        <div class="input-wrapper">
                            <i class="fas fa-clock"></i>
                            <input type="number" name="experience" placeholder="0" min="0">
                        </div>
                    </div>
                    <div class="btn-row">
                        <button type="button" class="btn btn-outline" onclick="nextStep(1)">Back</button>
                        <button type="button" class="btn btn-primary" onclick="nextStep(3)">
                            Continue <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>

                <!-- STEP 3: Security -->
                <div class="step" id="step-3">
                    <h2>Security Setup</h2>
                    <div class="form-group">
                        <label>Access Password</label>
                        <div class="input-wrapper">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" id="pass" placeholder="••••••••" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                        <div class="input-wrapper">
                            <i class="fas fa-check-double"></i>
                            <input type="password" name="confirm_password" id="conf" placeholder="••••••••" required>
                        </div>
                    </div>
                    <div class="btn-row">
                        <button type="button" class="btn btn-outline" onclick="nextStep(2)">Back</button>
                        <button type="submit" class="btn btn-primary" id="subBtn">
                            Create Account <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div id="toast"></div>

    <script>
        let current = 1;
        
        function nextStep(n) {
            document.querySelectorAll('.step').forEach(s => s.classList.remove('active'));
            document.querySelectorAll('.progress-item').forEach(p => p.classList.remove('active'));
            
            document.getElementById('step-' + n).classList.add('active');
            document.getElementById('p-' + n).classList.add('active');
            current = n;
        }

        const form = document.getElementById('regForm');
        const toast = document.getElementById('toast');
        const btn = document.getElementById('subBtn');

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (document.getElementById('pass').value !== document.getElementById('conf').value) {
                showToast('Passwords do not match!', '#ef4444');
                return;
            }

            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

            const formData = new FormData(form);

            try {
                const response = await fetch('api_register_teacher.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();

                if (data.success) {
                    showToast(data.message, '#10b981');
                    setTimeout(() => window.location.href = 'admin_dashboard.php', 2000);
                } else {
                    showToast(data.message, '#ef4444');
                }
            } catch (err) {
                showToast('Communication error', '#ef4444');
            } finally {
                btn.disabled = false;
                btn.innerHTML = 'Create Account <i class="fas fa-paper-plane"></i>';
            }
        });

        function showToast(msg, bg) {
            toast.innerText = msg;
            toast.style.background = bg;
            toast.style.display = 'block';
            setTimeout(() => toast.style.display = 'none', 4000);
        }
    </script>
</body>
</html>
