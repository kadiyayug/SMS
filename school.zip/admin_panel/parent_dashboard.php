<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'PARENT') {
    header("Location: index.php");
    exit;
}

include 'db.php';

$parent_user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

/* =========================
   CHILD INFO
========================= */
$child_q = mysqli_query($conn,"
    SELECT 
        s.id AS student_id,
        u.name AS student_name,
        s.class,
        s.batch
    FROM parents p
    JOIN students s ON p.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE p.user_id = '$parent_user_id'
");
$child = mysqli_fetch_assoc($child_q);
$student_id = $child['student_id'] ?? 0;

/* =========================
   ATTENDANCE SUMMARY
========================= */
$att_q = mysqli_query($conn,"
    SELECT 
        COUNT(*) AS total,
        SUM(status='P') AS present,
        SUM(status='A') AS absent
    FROM attendance
    WHERE student_id = '$student_id'
");
$att = mysqli_fetch_assoc($att_q);

$total = $att['total'] ?? 0;
$present = $att['present'] ?? 0;
$absent = $att['absent'] ?? 0;
$percentage = $total > 0 ? round(($present/$total)*100,2) : 0;

/* =========================
   NOTIFICATIONS
========================= */
$noti_q = mysqli_query($conn,"
    SELECT title, message, created_at, status
    FROM notifications
    WHERE (user_id = '$parent_user_id' OR user_id IS NULL)
    AND (role = '$role' OR role = 'ALL')
    ORDER BY created_at DESC 
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Parent Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-br from-indigo-50 to-blue-100 min-h-screen">

<!-- NAVBAR -->
<div class="bg-white shadow px-8 py-4 flex justify-between items-center">
    <h1 class="text-2xl font-bold text-indigo-600">👨‍👩‍👧 Parent Dashboard</h1>
    <a href="logout.php"
       class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600">
       Logout
    </a>
</div>

<div class="max-w-6xl mx-auto px-6 py-10">

<!-- CHILD INFO -->
<div class="mb-8">
    <h2 class="text-3xl font-bold text-gray-800">
        <?= htmlspecialchars($child['student_name']) ?>
    </h2>
    <p class="text-gray-600">
        Class <?= $child['class'] ?> | Batch <?= $child['batch'] ?>
    </p>
</div>

<!-- STATS -->
<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">

<div class="bg-white p-6 rounded-2xl shadow">
<p class="text-gray-500">Total Days</p>
<h3 class="text-3xl font-bold"><?= $total ?></h3>
</div>

<div class="bg-white p-6 rounded-2xl shadow">
<p class="text-gray-500">Present</p>
<h3 class="text-3xl font-bold text-green-600"><?= $present ?></h3>
</div>

<div class="bg-white p-6 rounded-2xl shadow">
<p class="text-gray-500">Absent</p>
<h3 class="text-3xl font-bold text-red-600"><?= $absent ?></h3>
</div>

<div class="bg-white p-6 rounded-2xl shadow">
<p class="text-gray-500">Attendance %</p>
<h3 class="text-3xl font-bold text-indigo-600"><?= $percentage ?>%</h3>
</div>

</div>

<!-- ACTIONS -->
<div class="bg-white p-8 rounded-3xl shadow-xl grid grid-cols-1 md:grid-cols-3 gap-6">

<a href="view_attendance.php"
class="px-6 py-4 bg-indigo-600 text-white rounded-xl text-center font-semibold hover:bg-indigo-700">
📅 View Attendance
</a>

<a href="view_materials.php"
class="px-6 py-4 bg-blue-600 text-white rounded-xl text-center font-semibold hover:bg-blue-700">
📚 Study Materials
</a>

<a href="parent_fees.php"
class="px-6 py-4 bg-green-600 text-white rounded-xl text-center font-semibold hover:bg-green-700 transition transform hover:scale-105">
💰 Fees Details
</a>

<a href="view_results.php"
class="px-6 py-4 bg-purple-600 text-white rounded-xl text-center font-semibold hover:bg-purple-700 transition transform hover:scale-105">
🏆 Exam Results
</a>

</div>

<!-- 🔔 NOTIFICATIONS -->
<div class="mt-10 bg-white p-8 rounded-3xl shadow-xl border border-indigo-50">
<div class="flex justify-between items-center mb-6">
    <h3 class="text-2xl font-bold text-gray-800 flex items-center gap-3">
        <span class="bg-indigo-100 p-2 rounded-xl text-lg">🔔</span> Recent Notifications
    </h3>
    <a href="notification_history.php" class="text-sm font-bold text-indigo-600 hover:text-indigo-800 uppercase tracking-wider">
        View All History →
    </a>
</div>

<?php if(mysqli_num_rows($noti_q) > 0): ?>
    <div class="space-y-4">
    <?php while($n = mysqli_fetch_assoc($noti_q)): ?>
        <div class="border-b last:border-0 pb-4 last:pb-0 hover:bg-slate-50 p-3 rounded-xl transition">
            <h4 class="font-bold text-gray-800"><?= htmlspecialchars($n['title'] ?? 'System Update') ?></h4>
            <p class="text-gray-600 mt-1">
                <?= htmlspecialchars($n['message']) ?>
            </p>
            <span class="text-[10px] font-bold text-gray-400 mt-2 block uppercase">
                <?= date('d M Y, h:i A', strtotime($n['created_at'])) ?>
            </span>
        </div>
    <?php endwhile; ?>
    </div>
<?php else: ?>
    <div class="text-center py-10">
        <p class="text-gray-400 italic">No notifications available.</p>
    </div>
<?php endif; ?>

</div>

</div>

<footer class="text-center text-gray-500 py-6">
© <?= date('Y') ?> School Management System
</footer>

</body>
</html>
