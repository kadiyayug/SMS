<?php
session_start();
include 'db.php';

// 🔒 Security: Only PARENT can update payments
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'PARENT') {
    header("Location: index.php");
    exit;
}

if (isset($_GET['fee_id']) && isset($_GET['payment_id'])) {
    $fee_id = $_GET['fee_id'];
    $payment_id = $_GET['payment_id'];
    $payment_date = date('Y-m-d H:i:s');

    // 🛡️ Prepared Statement to update status
    $stmt = mysqli_prepare($conn, "
        UPDATE fees f
        JOIN parents p ON f.student_id = p.student_id
        SET f.status = 'PAID', 
            f.razorpay_payment_id = ?, 
            f.payment_date = ?
        WHERE f.id = ? AND p.user_id = ?
    ");
    
    mysqli_stmt_bind_param($stmt, "ssii", $payment_id, $payment_date, $fee_id, $_SESSION['user_id']);
    
    if (mysqli_stmt_execute($stmt)) {
        // 🔔 NOTIFICATION FOR ADMIN
        $title = "Fee Payment Received";
        $message = "A payment of ₹(Auto) has been received for Fee ID #$fee_id (Payment ID: $payment_id).";
        $role = "ADMIN";
        
        $stmt_noti = mysqli_prepare($conn, "INSERT INTO notifications (title, message, role, status) VALUES (?, ?, ?, 'UNREAD')");
        mysqli_stmt_bind_param($stmt_noti, "sss", $title, $message, $role);
        mysqli_stmt_execute($stmt_noti);

        $success = true;
    } else {
        $error = "DB Update Failed: " . mysqli_stmt_error($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Success | Receipt</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">

<div class="max-w-md w-full bg-white rounded-3xl shadow-2xl p-10 text-center border-t-8 border-green-500">
    <?php if(isset($success)): ?>
        <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce">
            <i class="fas fa-check text-4xl text-green-600"></i>
        </div>
        <h2 class="text-3xl font-extrabold text-gray-800 mb-2 tracking-tight">Payment Received!</h2>
        <p class="text-gray-500 mb-8 font-medium">Your fee receipt has been updated instantly. Reference ID: <span class="text-indigo-600 font-bold"><?= htmlspecialchars($payment_id) ?></span></p>
        
        <div class="bg-gray-50 p-6 rounded-2xl border border-gray-100 mb-10 text-left">
            <div class="flex justify-between mb-2">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-widest">Transaction Date</span>
                <span class="text-xs font-bold text-gray-800 tracking-tight"><?= date('F j, Y, g:i A') ?></span>
            </div>
            <div class="flex justify-between">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-widest">Status</span>
                <span class="text-xs font-extrabold text-green-600 uppercase tracking-tighter">Verified</span>
            </div>
        </div>

        <a href="parent_fees.php" class="inline-block w-full bg-indigo-600 text-white font-black py-4 rounded-2xl hover:bg-indigo-700 transition active:scale-95 shadow-lg shadow-indigo-100 uppercase tracking-widest text-xs">
            Return to Ledger
        </a>
    <?php else: ?>
        <div class="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-8">
            <i class="fas fa-times text-4xl text-red-600"></i>
        </div>
        <h2 class="text-2xl font-bold text-gray-800 mb-2">Processing Error</h2>
        <p class="text-gray-500 mb-8"><?= $error ?? 'Invalid request.' ?></p>
        <a href="parent_fees.php" class="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-100">Try Again</a>
    <?php endif; ?>
</div>

</body>
</html>
