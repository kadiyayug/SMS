<?php
session_start();
include 'db.php';

// 🔒 Access Control: Only ADMIN or TEACHER can upload
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER'])) {
    header("Location: dashboard.php");
    exit;
}

$msg = "";
$msg_type = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $class       = trim($_POST['class'] ?? '');
    $subject     = trim($_POST['subject'] ?? '');
    $user_id     = $_SESSION['user_id'];

    if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
        $allowed = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt', 'jpg', 'png'];
        $filename = $_FILES['file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (in_array($ext, $allowed)) {
            $upload_dir = 'uploads/materials/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $new_name = uniqid('material_', true) . '.' . $ext;
            $destination = $upload_dir . $new_name;

            if (move_uploaded_file($_FILES['file']['tmp_name'], $destination)) {
                // 🛡️ Prepared Statement
                $stmt = mysqli_prepare($conn, "INSERT INTO study_materials (title, description, file_path, class, subject, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "sssssi", $title, $description, $destination, $class, $subject, $user_id);
                
                if (mysqli_stmt_execute($stmt)) {
                    $msg = "Material uploaded successfully!";
                    $msg_type = "success";
                } else {
                    $msg = "DB Error: " . mysqli_stmt_error($stmt);
                    $msg_type = "error";
                }
            } else {
                $msg = "Failed to move uploaded file.";
                $msg_type = "error";
            }
        } else {
            $msg = "Invalid file type. Allowed: PDF, DOC, PPT, TXT, Images.";
            $msg_type = "error";
        }
    } else {
        $msg = "Please select a valid file.";
        $msg_type = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload Study Material</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 min-h-screen">

<nav class="bg-white shadow-lg px-8 py-4 flex justify-between items-center">
    <div class="flex items-center gap-3">
        <div class="bg-blue-600 p-2 rounded-lg">
            <i class="fas fa-book-open text-white"></i>
        </div>
        <h1 class="text-xl font-bold text-gray-800 tracking-tight">Study Materials</h1>
    </div>
    <?php 
        $dash = ($_SESSION['role']==='ADMIN') ? 'admin_dashboard.php' : 'teacher_dashboard.php';
    ?>
    <a href="<?= $dash ?>" class="text-gray-600 hover:text-blue-600 font-medium transition flex items-center gap-2">
        <i class="fas fa-arrow-left"></i> Dashboard
    </a>
</nav>

<main class="max-w-2xl mx-auto py-12 px-6">
    <div class="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <h2 class="text-2xl font-bold text-gray-800 mb-2">Upload New Material</h2>
        <p class="text-gray-500 mb-8">Share documents, notes, or resources with your students.</p>

        <?php if($msg): ?>
        <div class="mb-6 p-4 rounded-xl flex items-center gap-3 <?= $msg_type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100' ?>">
            <i class="fas <?= $msg_type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
            <span class="font-medium"><?= $msg ?></span>
        </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data" class="space-y-6">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Title</label>
                <input type="text" name="title" required placeholder="e.g. Mathematics Chapter 5 Notes"
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition">
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Description (Optional)</label>
                <textarea name="description" rows="3" placeholder="Explain what this material covers..."
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"></textarea>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Target Class</label>
                    <input type="text" name="class" placeholder="e.g. 10th Standard"
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Subject</label>
                    <input type="text" name="subject" placeholder="e.g. Algebra"
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition">
                </div>
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Select File</label>
                <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-xl hover:border-blue-500 transition-colors">
                    <div class="space-y-1 text-center">
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3 block"></i>
                        <div class="flex text-sm text-gray-600">
                            <label class="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none">
                                <span>Upload a file</span>
                                <input name="file" type="file" class="sr-only" required>
                            </label>
                            <p class="pl-1">or drag and drop</p>
                        </div>
                        <p class="text-xs text-gray-500">PDF, DOC, PPT up to 10MB</p>
                    </div>
                </div>
            </div>

            <button type="submit" class="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 active:scale-95 transition shadow-lg shadow-blue-200 uppercase tracking-wider">
                Publish Material
            </button>
        </form>
    </div>
</main>

<footer class="text-center py-8 text-gray-400 text-sm">
    &copy; <?= date('Y') ?> School Management Professional Portal
</footer>

</body>
</html>
