<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: admin_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance | Fees Management Dashboard</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #10b981;
            --primary-dark: #059669;
            --secondary: #6366f1;
            --danger: #ef4444;
            --glass: rgba(255, 255, 255, 0.7);
            --glass-border: rgba(255, 255, 255, 0.1);
            --bg-color: #f8fafc;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }

        body {
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(at 0% 0%, rgba(16, 185, 129, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(99, 102, 241, 0.05) 0px, transparent 50%);
            min-height: 100vh;
            color: #1e293b;
        }

        /* Navigation */
        nav {
            padding: 20px 40px;
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--glass-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-brand { font-size: 24px; font-weight: 800; color: var(--primary-dark); display: flex; align-items: center; gap: 10px; }
        .nav-brand i { background: var(--primary); color: white; width: 40px; height: 40px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; }

        .nav-actions { display: flex; gap: 15px; }

        /* Main Container */
        main { max-width: 1300px; margin: 40px auto; padding: 0 30px; }

        /* Stats Cards */
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-bottom: 40px; }
        .stat-card {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            padding: 30px;
            border-radius: 32px;
            box-shadow: 0 10px 30px -10px rgba(0,0,0,0.05);
            transition: 0.3s forwards;
        }
        .stat-card h3 { color: #64748b; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px; }
        .stat-card .val { font-size: 32px; font-weight: 800; color: #1e293b; }
        .stat-card .trend { font-size: 14px; font-weight: 600; margin-left: 10px; }
        .stat-card.emerald .trend { color: var(--primary); }

        /* Table Container */
        .table-area {
            background: white;
            border-radius: 32px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05);
            overflow: hidden;
            animation: fadeIn 0.8s ease;
        }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

        .table-header { padding: 30px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9; }
        .table-header h2 { font-size: 22px; font-weight: 700; }

        .search-box {
            position: relative;
            width: 350px;
        }
        .search-box i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #94a3b8; }
        .search-box input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 1.5px solid #e2e8f0;
            border-radius: 14px;
            font-size: 14px;
            outline: none;
            transition: 0.3s;
        }
        .search-box input:focus { border-color: var(--primary); box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1); }

        /* Table Design */
        #records-table { width: 100%; border-collapse: collapse; }
        #records-table th { background: #f8fafc; padding: 20px 30px; text-align: left; font-size: 13px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        #records-table td { padding: 20px 30px; border-bottom: 1px solid #f1f5f9; font-size: 15px; color: #334155; }
        #records-table tr:hover td { background: #fdfdfd; }

        .badge { padding: 6px 12px; border-radius: 50px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .badge-paid { background: #ecfdf5; color: #059669; }
        .badge-pending { background: #fef2f2; color: #dc2626; }

        .actions { display: flex; gap: 8px; }
        .btn-icon { width: 35px; height: 35px; border-radius: 10px; display: flex; align-items: center; justify-content: center; border: none; cursor: pointer; transition: 0.2s; background: #f1f5f9; color: #64748b; }
        .btn-icon:hover { background: #e2e8f0; color: #1e293b; }
        .btn-icon.del:hover { background: #fee2e2; color: #ef4444; }

        .btn { padding: 12px 24px; border-radius: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 8px; transition: 0.3s; }
        .btn-primary { background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%); color: white; box-shadow: 0 10px 15px -3px rgba(16, 185, 129, 0.3); }
        .btn-secondary { background: white; border: 1.5px solid #e2e8f0; color: #334155; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 15px 25px -5px rgba(0,0,0,0.1); }

        @media (max-width: 1024px) { .stats-grid { grid-template-columns: 1fr; } .search-box { width: 100%; margin-top: 15px; } .table-header { flex-direction: column; align-items: flex-start; } }
    </style>
</head>
<body>

    <nav>
        <div class="nav-brand">
            <i class="fas fa-wallet"></i>
            Finance Hub
        </div>
        <div class="nav-actions">
            <a href="admin_dashboard.php" class="btn btn-secondary"><i class="fas fa-home"></i> Dashboard</a>
            <a href="add_fee.php" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Record Fee</a>
        </div>
    </nav>

    <main>
        <!-- Stats Overview -->
        <div class="stats-grid">
            <div class="stat-card emerald">
                <h3>Total Collection</h3>
                <div class="flex items-baseline">
                    <span class="val" id="total-val">₹ 0</span>
                    <span class="trend"><i class="fas fa-arrow-up"></i> 12.5%</span>
                </div>
            </div>
            <div class="stat-card">
                <h3>Paid Records</h3>
                <div class="val" id="paid-count">0</div>
            </div>
            <div class="stat-card">
                <h3>Pending Dues</h3>
                <div class="val" id="pending-count">0</div>
            </div>
        </div>

        <!-- Records Table -->
        <div class="table-area">
            <div class="table-header">
                <h2>Transaction History</h2>
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search by student name or Payment ID...">
                </div>
            </div>

            <table id="records-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Transaction ID</th>
                        <th>Date & Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    <!-- Data will be loaded via AJAX -->
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 50px; color: #94a3b8;">
                            <i class="fas fa-spinner fa-spin" style="margin-right: 10px;"></i> Syncing with ledger...
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </main>

    <script>
        let allRecords = [];

        async function fetchRecords() {
            try {
                const res = await fetch('api_fees.php?action=list');
                const result = await res.json();
                
                if (result.status === 'success') {
                    allRecords = result.data;
                    renderTable(allRecords);
                    updateStats(allRecords);
                }
            } catch (err) {
                console.error("Ledger sync failed:", err);
            }
        }

        function renderTable(data) {
            const body = document.getElementById('tableBody');
            if (data.length === 0) {
                body.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 50px;">No transaction records found.</td></tr>';
                return;
            }

            body.innerHTML = data.map(row => `
                <tr>
                    <td><b>${row.student_name}</b></td>
                    <td><span style="font-weight: 700;">${row.formatted_amount}</span></td>
                    <td>
                        <span class="badge ${row.status === 'PAID' ? 'badge-paid' : 'badge-pending'}">
                            ${row.status}
                        </span>
                    </td>
                    <td><code style="font-size: 12px; color: #64748b;">${row.razorpay_payment_id || 'INTERNAL'}</code></td>
                    <td>${row.formatted_date}</td>
                    <td class="actions">
                        <button class="btn-icon" title="View Receipt"><i class="fas fa-file-invoice"></i></button>
                        <button class="btn-icon del" onclick="deleteRecord(${row.id})" title="Purge Record"><i class="fas fa-trash-alt"></i></button>
                    </td>
                </tr>
            `).join('');
        }

        function updateStats(data) {
            const total = data.reduce((acc, curr) => acc + parseFloat(curr.amount), 0);
            const paid = data.filter(r => r.status === 'PAID').length;
            const pending = data.filter(r => r.status === 'PENDING').length;

            document.getElementById('total-val').innerText = '₹ ' + total.toLocaleString();
            document.getElementById('paid-count').innerText = paid;
            document.getElementById('pending-count').innerText = pending;
        }

        // Search Filter
        document.getElementById('searchInput').addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            const filtered = allRecords.filter(r => 
                r.student_name.toLowerCase().includes(term) || 
                (r.razorpay_payment_id && r.razorpay_payment_id.toLowerCase().includes(term))
            );
            renderTable(filtered);
        });

        async function deleteRecord(id) {
            if (!confirm('Permanent action. Delete record ID: #' + id + '?')) return;
            
            try {
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('id', id);

                const res = await fetch('api_fees.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await res.json();
                
                if (result.status === 'success') {
                    fetchRecords(); // Refresh
                } else {
                    alert(result.message);
                }
            } catch (err) {
                alert('Internal system error.');
            }
        }

        // Initial Load
        fetchRecords();
    </script>

</body>
</html>
